<html>
<head>
    <title>Banking System</title>
    <link rel="shortcut icon" href="images/cm.jpg">
    <link rel="stylesheet" href="style.css">
</head>
<body >
<div id="header">
       <br>
       <h1 style=" font-family:Agency FB; font-size: 70px  ; "> Internship Project </h1>
       <br>
       <h2 style=" font-family:Agency FB; font-size: 55px  ; "> Easy Banking System </h2>
        </div>
        <div id="section">
            <table>
                <tr></tr>
                <tr>        
               
                <div class="css-button" >
                  <p class="css-button-text">Show Users</p>
                  <div class="css-button-inner">
                  <a href="getdetail.php" >
                  <div class="reset-skew">
                  <p class="css-button-inner-text">Show Users</p>
                </div></a>
                </div>
                </div>

                </td>
                </tr>

                <tr>        
               <br> <br> <br> <br> <br>
               <div class="css-button" >
                 <p class="css-button-text">Money Transfer</p>
                 <div class="css-button-inner">
                 <a href="selectuser.php" >
                 <div class="reset-skew">
                 <p class="css-button-inner-text">Money Transfer</p>
               </div></a>
               </div>
               </div>

               </td>
               </tr>

            </table>
    </div>

</body>
</html>